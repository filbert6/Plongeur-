
export interface HorseData {
  number: number;
  name: string;
  jockey: string;
  trainer: string;
  odds: string;
  musique: string;
  winProbability: number;
  attributes: {
    speed: number;
    stamina: number;
    form: number;
    trackCompatibility: number;
    jockeySkill: number;
  };
}

export interface PredictionResult {
  quinte: number[];
  alternates: number[];
  analysis: string;
  sources: { title: string; url: string }[];
  deepThinking?: string;
}

export interface RaceInfo {
  title: string;
  date: string;
  location: string;
  distance: string;
  ground: string;
  prize: string;
}
