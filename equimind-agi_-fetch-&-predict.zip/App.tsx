
import React, { useState } from 'react';
import Header from './components/Header';
import PredictionDashboard from './components/PredictionDashboard';
import RaceLinkInput from './components/RaceLinkInput';
import { PredictionResult } from './types';
import { fetchRaceDataAndPredict } from './geminiService';

const App: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handlePredict = async (url: string) => {
    setLoading(true);
    setError(null);
    try {
      const result = await fetchRaceDataAndPredict(url);
      setPrediction(result);
    } catch (err) {
      setError("Une erreur est survenue lors de l'analyse AGI. Veuillez vérifier l'URL et réessayer.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8 max-w-6xl">
        <section className="mb-12 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-emerald-400">
            Fetch & Predict
          </h1>
          <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto">
            Propulsé par l'AGI de nouvelle génération. Collez un lien de course, laissez l'IA parcourir le web et générer une prédiction probabiliste ultra-précise.
          </p>
        </section>

        <div className="flex justify-center mb-12">
          <RaceLinkInput onPredict={handlePredict} isLoading={loading} />
        </div>

        {error && (
          <div className="bg-red-900/20 border border-red-500/50 p-4 rounded-lg mb-8 text-red-200 text-center">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-6">
            <div className="relative w-24 h-24">
              <div className="absolute inset-0 border-4 border-blue-500/20 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-t-blue-500 rounded-full animate-spin"></div>
            </div>
            <div className="text-center">
              <p className="text-xl font-medium animate-pulse text-blue-400">Traitement AGI en cours...</p>
              <p className="text-sm text-slate-500 mt-2">Récupération des métriques, calcul des probabilités, analyse du terrain</p>
            </div>
          </div>
        ) : prediction ? (
          <PredictionDashboard prediction={prediction} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-60">
            <FeatureCard title="Deep Learning" desc="Modèles de transformateurs entraînés sur des décennies de courses hippiques." icon="🧠" />
            <FeatureCard title="Live Fetching" desc="Recherche en temps réel des dernières cotes et changements de météo." icon="🌐" />
            <FeatureCard title="Probabilistic Engine" desc="Calcul du risque et de la variance pour chaque partant." icon="📊" />
          </div>
        )}
      </main>

      <footer className="py-8 border-t border-slate-800 text-center text-slate-500 text-sm">
        &copy; {new Date().getFullYear()} EquiMind AGI. Utilisation réservée aux analyses prédictives avancées.
      </footer>
    </div>
  );
};

const FeatureCard = ({ title, desc, icon }: { title: string, desc: string, icon: string }) => (
  <div className="glass p-6 rounded-2xl border border-white/5">
    <div className="text-3xl mb-4">{icon}</div>
    <h3 className="text-lg font-semibold mb-2">{title}</h3>
    <p className="text-slate-400 text-sm">{desc}</p>
  </div>
);

export default App;
