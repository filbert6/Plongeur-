
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { PredictionResult } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const fetchRaceDataAndPredict = async (raceUrl: string): Promise<PredictionResult> => {
  const model = "gemini-3-pro-preview";
  
  const systemInstruction = `
    Tu es EquiMind AGI, une Intelligence Artificielle Générale spécialisée dans l'analyse de courses hippiques (Quinté+).
    Ton objectif est d'analyser le lien fourni par l'utilisateur, de récupérer TOUTES les données statistiques pertinentes via Google Search (jockeys, musique, entraîneurs, métriques de vitesse, état du terrain, cotes en direct) et de produire une prédiction probabiliste.
    
    Structure ta réponse de manière ultra-professionnelle.
    Utilise le 'thinking' pour simuler une réflexion AGI profonde avant de donner ton pronostic.
    Identifie les 5 chevaux du Quinté+ avec des probabilités de victoire.
    Retourne toujours les sources (URL) trouvées via Google Search.
  `;

  const prompt = `Analyse cette course hippique : ${raceUrl}. 
  Identifie les chevaux partants, leurs statistiques complètes, l'état de la piste, et les favoris de la presse spécialisée (Equidia, Zeturf, PMU).
  Fais une synthèse AGI pour prédire le Quinté+ de demain/aujourd'hui basé sur ce lien.`;

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 32768 }
      },
    });

    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'Source',
      url: chunk.web?.uri || ''
    })) || [];

    // Note: Gemini text property returns the main response. 
    // We expect the model to provide the Quinte numbers in its text.
    // For a real production app, we would use a JSON schema, 
    // but googleSearch grounding doesn't support responseSchema in Gemini 3 yet.
    
    return {
      analysis: response.text || "Aucune analyse générée.",
      quinte: extractNumbers(response.text || ""),
      alternates: [], // Could be extracted if model provides them
      sources: sources,
      deepThinking: "" // In a real SDK, thinking would be in a separate field if supported via candidates
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

function extractNumbers(text: string): number[] {
  const numbers = text.match(/\b\d{1,2}\b/g);
  if (!numbers) return [];
  // Return unique top 5 found (heuristically looking for horse numbers)
  return Array.from(new Set(numbers.map(Number))).filter(n => n > 0 && n <= 24).slice(0, 5);
}
