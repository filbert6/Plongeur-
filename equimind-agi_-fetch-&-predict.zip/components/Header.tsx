
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 glass border-b border-white/10 px-6 py-4">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-lg flex items-center justify-center">
            <span className="text-white font-bold">E</span>
          </div>
          <span className="text-xl font-bold tracking-tight">EquiMind <span className="text-blue-400">AGI</span></span>
        </div>
        <nav className="hidden md:flex space-x-8 text-sm font-medium text-slate-400">
          <a href="#" className="hover:text-blue-400 transition-colors">Tableau de bord</a>
          <a href="#" className="hover:text-blue-400 transition-colors">Historique</a>
          <a href="#" className="hover:text-blue-400 transition-colors">Documentation</a>
        </nav>
        <div>
          <button className="bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-full text-sm font-medium transition-all shadow-lg shadow-blue-500/20">
            Mode Premium
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
