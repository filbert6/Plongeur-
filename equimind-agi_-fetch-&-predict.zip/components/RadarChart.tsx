
import React from 'react';

const RadarChart: React.FC = () => {
  // Static visual for demo purposes
  return (
    <svg viewBox="0 0 200 200" className="w-full h-full">
      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{ stopColor: '#3b82f6', stopOpacity: 0.8 }} />
          <stop offset="100%" style={{ stopColor: '#10b981', stopOpacity: 0.8 }} />
        </linearGradient>
      </defs>
      {/* Grid Lines */}
      <circle cx="100" cy="100" r="80" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      <circle cx="100" cy="100" r="60" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      <circle cx="100" cy="100" r="40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      <circle cx="100" cy="100" r="20" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      
      {/* Axes */}
      <line x1="100" y1="20" x2="100" y2="180" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      <line x1="20" y1="100" x2="180" y2="100" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      
      {/* Data Polygon */}
      <polygon 
        points="100,30 170,100 100,160 30,100" 
        fill="url(#grad)"
        stroke="#3b82f6"
        strokeWidth="2"
        className="animate-pulse"
      />
      
      {/* Labels */}
      <text x="100" y="15" textAnchor="middle" fill="#94a3b8" fontSize="8" className="font-bold">VITESSE</text>
      <text x="190" y="105" textAnchor="end" fill="#94a3b8" fontSize="8" className="font-bold">FORME</text>
      <text x="100" y="195" textAnchor="middle" fill="#94a3b8" fontSize="8" className="font-bold">ENDURANCE</text>
      <text x="10" y="105" textAnchor="start" fill="#94a3b8" fontSize="8" className="font-bold">TRACK</text>
    </svg>
  );
};

export default RadarChart;
