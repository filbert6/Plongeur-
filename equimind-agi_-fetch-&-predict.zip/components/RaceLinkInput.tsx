
import React, { useState } from 'react';

interface Props {
  onPredict: (url: string) => void;
  isLoading: boolean;
}

const RaceLinkInput: React.FC<Props> = ({ onPredict, isLoading }) => {
  const [url, setUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      onPredict(url.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-3xl">
      <div className="relative flex flex-col md:flex-row gap-4">
        <input
          type="text"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://www.pmu.fr/turf/..."
          disabled={isLoading}
          className="flex-grow glass border border-white/20 rounded-2xl px-6 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all text-slate-200 placeholder-slate-500"
        />
        <button
          type="submit"
          disabled={isLoading || !url.trim()}
          className={`px-8 py-4 rounded-2xl font-bold transition-all flex items-center justify-center space-x-2
            ${isLoading ? 'bg-slate-700 text-slate-400 cursor-not-allowed' : 'bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-500 hover:to-emerald-500 text-white shadow-xl shadow-blue-500/10'}
          `}
        >
          {isLoading ? (
            <span>Analyse...</span>
          ) : (
            <>
              <span>Prédire</span>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </>
          )}
        </button>
      </div>
      <p className="text-xs text-slate-500 mt-3 ml-2">Ex: PMU, Equidia, Zeturf, Geny. L'AGI extraira toutes les métriques.</p>
    </form>
  );
};

export default RaceLinkInput;
