
import React from 'react';
import { PredictionResult } from '../types';
import RadarChart from './RadarChart';

interface Props {
  prediction: PredictionResult;
}

const PredictionDashboard: React.FC<Props> = ({ prediction }) => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      {/* Quinté Card */}
      <div className="glass p-8 rounded-3xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10">
          <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9v-2h2v2zm0-4H9V7h2v5z"/></svg>
        </div>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div>
            <h2 className="text-2xl font-bold mb-1">Pronostic Quinté+ AGI</h2>
            <p className="text-blue-400 font-medium uppercase tracking-wider text-xs">Probabilités de succès estimées : High Confidence</p>
          </div>
          <div className="flex gap-4">
            {prediction.quinte.map((num, i) => (
              <div key={i} className="w-14 h-14 bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-blue-500/50 rounded-full flex items-center justify-center shadow-xl shadow-blue-900/20">
                <span className="text-2xl font-black text-white">{num}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Analysis Text */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <span className="text-emerald-400">●</span> Analyse Cognitive
            </h3>
            <div className="prose prose-invert max-w-none text-slate-300 text-sm leading-relaxed whitespace-pre-wrap">
              {prediction.analysis}
            </div>
          </div>

          {/* Metrics Radar / Data */}
          <div className="bg-slate-900/40 rounded-2xl p-6 border border-white/5">
            <h3 className="text-lg font-semibold mb-6">Matrice de Performance</h3>
            <div className="h-64 flex items-center justify-center">
              <RadarChart />
            </div>
            <div className="grid grid-cols-2 gap-4 mt-6">
              <MetricItem label="Vitesse de pointe" value="94%" />
              <MetricItem label="Indice de Forme" value="88%" />
              <MetricItem label="Stabilité" value="76%" />
              <MetricItem label="Affinité Terrain" value="82%" />
            </div>
          </div>
        </div>
      </div>

      {/* Sources & Grounding */}
      <div className="glass p-6 rounded-3xl">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-blue-400" viewBox="0 0 20 20" fill="currentColor">
            <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
          </svg>
          Sources de Données (Grounding)
        </h3>
        <div className="flex flex-wrap gap-3">
          {prediction.sources.map((src, i) => (
            <a 
              key={i} 
              href={src.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs text-blue-300 transition-colors truncate max-w-xs"
            >
              {src.title}
            </a>
          ))}
          {prediction.sources.length === 0 && <span className="text-slate-500 text-xs italic">Aucune source directe détectée dans le prompt.</span>}
        </div>
      </div>
    </div>
  );
};

const MetricItem = ({ label, value }: { label: string, value: string }) => (
  <div className="flex justify-between items-center bg-white/5 px-4 py-2 rounded-lg">
    <span className="text-xs text-slate-400">{label}</span>
    <span className="text-sm font-bold text-emerald-400">{value}</span>
  </div>
);

export default PredictionDashboard;
